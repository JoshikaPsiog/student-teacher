export interface User {
  id: number;
  name: string;
  email: string;
  role: string; // "Teacher" or "Student"
  password?: string;
}
